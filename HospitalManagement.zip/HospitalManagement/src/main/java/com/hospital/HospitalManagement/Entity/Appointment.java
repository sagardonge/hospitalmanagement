package com.hospital.HospitalManagement.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Appointment")
public class Appointment {

	@Id
	private int id;
	private String name;
	private int age;
	private String gender;
	private String problem;
	private String date;
	private String contact;
	private String address;
	
//	public Appointment() {}
	

//	public Appointment(int id, String patientname, int age, String gender, String problem, String date, int contact,
//			String address) {
//		super();
//		this.id = id;
//		this.patientname = patientname;
//		this.age = age;
//		this.gender = gender;
//		this.problem = problem;
//		this.date = date;
//		this.contact = contact;
//		this.address = address;
//	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getname() {
		return name;
	}

	public void setname(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getProblem() {
		return problem;
	}

	public void setProblem(String problem) {
		this.problem = problem;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Appointment [id=" + id + ", name=" + name + ", age=" + age + ", gender=" + gender
				+ ", problem=" + problem + ", date=" + date + ", contact=" + contact + ", address=" + address + "]";
	}

}
