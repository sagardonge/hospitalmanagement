package com.hospital.HospitalManagement.service;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hospital.HospitalManagement.Entity.Appointment;
import com.hospital.HospitalManagement.Entity.Hospital;
import com.hospital.HospitalManagement.dao.Dao;

@org.springframework.stereotype.Service
public class Service {

	@Autowired
	Dao dd;

	public List<Hospital> GetData() {
		List<Hospital> data = dd.GetData();
		return data;
	}

	public String Appointment(Appointment appo) {
		return dd.Appointment(appo);
	}

	public List<Appointment> GetUserData() {
		return dd.GetUserData();
	}
		
	
	public String DeleteUserData(int id) {		
		return dd.DeleteUserData(id);
	}
}
