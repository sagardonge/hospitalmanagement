package com.hospital.HospitalManagement.dao;

import java.util.List;

import javax.persistence.Id;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hospital.HospitalManagement.Entity.Appointment;
import com.hospital.HospitalManagement.Entity.Hospital;

@Repository
public class Dao {

	@Autowired
	SessionFactory sf;

	public List<Hospital> GetData() {

		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Hospital.class);

		return ctr.list();
	}

	public String Appointment(Appointment appo) {

		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(appo);
		tr.commit();
		session.close();
		return "Data Saved...";
	}

	public List<Appointment> GetUserData() {

		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Appointment.class);
		return ctr.list();
	}
	
	
	
	public String DeleteUserData(int id) {
		
		Session session=sf.openSession();
		Transaction tr=session.beginTransaction();
		Appointment ap=session.get(Appointment.class, id);
		
		session.delete(ap);
		tr.commit();
		session.close();
		
		return "Data Deleted";
		
		
	}

}
