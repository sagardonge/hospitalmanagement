package com.hospital.HospitalManagement.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hospital.HospitalManagement.Entity.Appointment;
import com.hospital.HospitalManagement.Entity.Hospital;
import com.hospital.HospitalManagement.service.Service;

@org.springframework.stereotype.Controller
public class Controller {

	@Autowired
	Service ss;

	// get all doctor name list on our doctor page
	@GetMapping("/ourDoctors")
	public ModelAndView GetData() {

		ModelAndView view = new ModelAndView();
		view.setViewName("ourdoctors");

		List<Hospital> list = ss.GetData();
		view.addObject("alldata", list);

		return view;
	}

	// display home page
	@GetMapping("/index")
	public String Homepage() {
		return "index";
	}

	// display about us page
	@GetMapping("/aboutUs")
	public String Aboutus() {
		System.out.println("This is about us page");
		return "AboutUs";
	}

	// display department page
	@GetMapping("/department")
	public String Department() {
		System.out.println("This is department page");
		return "department";
	}

	// display faculty page
	@GetMapping("/faculty")
	public String Faculty() {
		System.out.println("This is faculty page");
		return "faculty";
	}

	// display appointment page
	@RequestMapping("/appointment")
	public String appo() {
		return "appointment";
	}

	// display appointment registration page
	@RequestMapping(path = "/formprocess", method = RequestMethod.POST)
	public String handleform(@ModelAttribute Appointment appo) {

		ss.Appointment(appo);

		
		return "success";
	}

	// display appointment booked successful page
	@GetMapping("/success")
	public String Continue() {

		return "index";

	}

	// display services page
	@GetMapping("/services")
	public String Services() {

		return "services";
	}

	// display contact us page
	@GetMapping("/contact")
	public String ContactUs() {
		System.out.println("This is contact page");

		return "contact";
	}

	@GetMapping("/cancel")
	public String Cancel() {
		System.out.println("This is home page");

		return "index";
	}

	@GetMapping("/admin")
	public String AdminLogin() {

		return "adminlogin";
	}

	// @GetMapping("/userdata")
	// public String UserData() {
	//
	// return "userdata";
	// }

	// Get All User Appointment list data on userdata page
	@GetMapping("/userdata")
	public ModelAndView GetUserData() {

		ModelAndView view = new ModelAndView();
		view.setViewName("userdata");

		List<Appointment> list = ss.GetUserData();
		view.addObject("getuserdata", list);

		return view;
	}

	@RequestMapping("/delete/{id}")
	public String DeleteUserData(@PathVariable int id) {

		String msg = ss.DeleteUserData(id);

		return msg;
	}



}
