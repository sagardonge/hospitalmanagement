package com.hospital.HospitalManagement.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Hospital {

	@Id
	private int id;
	private String doctorname;
	private String designation;
	private String department;
	private String eduqualification;



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDoctorname() {
		return doctorname;
	}

	public void setDoctorname(String doctorname) {
		this.doctorname = doctorname;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getEduqualification() {
		return eduqualification;
	}

	public void setEduqualification(String eduqualification) {
		this.eduqualification = eduqualification;
	}

	@Override
	public String toString() {
		return "Hospital [id=" + id + ", doctorname=" + doctorname + ", designation=" + designation + ", department="
				+ department + ", eduqualification=" + eduqualification + "]";
	}

}
